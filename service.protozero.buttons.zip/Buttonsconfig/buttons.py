#!/usr/bin/python

import sys
sys.path.append('/storage/.kodi/addons/python.RPi.GPIO/lib')

import RPi.GPIO as GPIO
import xbmc

'''
upPin =       # board pin 11
downPin = 27    # board pin 13
leftPin = 22    # board pin 15
rightPin = 6    # board pin 31
'''
selectPin = 20    # board pin 38
shiftPin = 21    # board pin 40


def up_callback(channel):
    if(GPIO.input(shiftPin)):
        xbmc.executebuiltin("Action(Back)")
'''

def down_callback(channel):
    if(GPIO.input(shiftPin)):
        xbmc.executebuiltin("Action(Down)")
    else:
        xbmc.executebuiltin("Action(Info)")
      
def left_callback(channel):
    if(GPIO.input(shiftPin)):
        xbmc.executebuiltin("Action(Left)")
    else:
        xbmc.executebuiltin("Action(Stop)")

def right_callback(channel):
    if(GPIO.input(shiftPin)):
        xbmc.executebuiltin("Action(Right)")
    else:
        xbmc.executebuiltin("Action(PlayPause)")
'''
def select_callback(channel):
    if(GPIO.input(selectPin)):
        xbmc.executebuiltin("Action(Select)")

class Main:
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    '''
    GPIO.setup(upPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(downPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(leftPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(rightPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    '''
    GPIO.setup(selectPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(shiftPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    '''
    GPIO.add_event_detect(upPin, GPIO.FALLING, callback=up_callback, bouncetime=300)
    GPIO.add_event_detect(downPin, GPIO.FALLING, callback=down_callback, bouncetime=300)
    GPIO.add_event_detect(leftPin, GPIO.FALLING, callback=left_callback, bouncetime=300)
    GPIO.add_event_detect(rightPin, GPIO.FALLING, callback=right_callback, bouncetime=300)
    '''
    GPIO.add_event_detect(selectPin, GPIO.FALLING, callback=select_callback, bouncetime=300)

    monitor=xbmc.Monitor()

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

    GPIO.cleanup([selectPin,shiftPin])        
        
if (__name__ == "__main__"):
    Main()